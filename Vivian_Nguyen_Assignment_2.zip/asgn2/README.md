Author: Vivian Nguyen
1971079
Davis - Winter 2026 
CSE 160

site:
https://iviang.github.io/CSE-160/asgn2/src/BlockyAnimal.html

Blocky 3D Animal - Rat

Non-cube primitive: Sphere.js, Cone.js
Poke Animation (Shift-Click): barrel roll

notes:
I included a start/stop button for a full body animation. If during that process, any of the individual animations are turned on, they will keep running after the full body animation is stopped. However, the when the full body animation is running, the individual parts can't be stopped by the individual "Off" buttons, only its own "Stop" button.
"Wiggle": Subtly moves the lower half (the butt) of the rat.
"Wag Tail": The slider moves the whole tail with just the base section. The animation is different, I made it so that it moves all joints of the tail in a more fluid motion.

References:
refrenced asgn1
used youtube playlist for guidance
used the WebGL textbook for guidance
used gpt for debug support
live preview extension vs code to see live changes
implemented a sphere class to make eyes
https://stackoverflow.com/questions/43325301/java-beginner-sphere-class 
http://blog.andreaskahler.com/2009/06/creating-icosphere-mesh-in-code.html
https://en.wikipedia.org/wiki/Equirectangular_projection
implemented cone (tail, ears)
https://www.songho.ca/opengl/gl_cone.html#:~:text=The%20base%20radius%20and%20height,them%20by%20the%20given%20radius. 
Rat pictures
Rat walking video for reference: https://www.youtube.com/watch?v=qsJ3Zlae5Cg 
https://developer.mozilla.org/en-US/docs/Web/API/MouseEvent/shiftKey

