Author: Vivian Nguyen
1971079
Davis - Winter 2026 
CSE 160

site:
https://iviang.github.io/CSE-160/asgn4/light/asgn4.html
http://localhost:8000/asgn4/light/asgn4.html

Notes:
I have implemented my rat from the asgn2.
I made the cheese ball, rat eyes, and rat nose shiny, while the other components are made matte.
Cheese cubes are matte.
rat body is matte.
I already had a sphere class from when I made asgn2 so I reused it but did end up changing it a bit.

For total no light, both Light and Spotlight have to be "Off".
Spotlight does incorporate diffuse, ambient, and specular. 
Since some textures were purposefully made not shiny, the shiny highlights are a bit less obvious but are there if you move the camera closer.

object is teapot

Controls:================================
MOVEMENT KEYS:
WASD

CAMERA ROTATION: 
Q, E, MOUSE

References:
asgn4 pdf
refrenced asgn2 construction 
- sphere class made for animal shape
- reused animal
refrenced asgn3 construction
- camera class reused
- textures reused
referenced OBJ lab Model.js
- using teapot.obj
used youtube playlist for guidance
used the WebGL textbook for guidance (8. Lighting and Heirarchical Objects)
used gpt for debug support
http://www.lighthouse3d.com/tutorials/glsl-12-tutorial/the-normal-matrix/ 
https://en.wikipedia.org/wiki/Spherical_coordinate_system
https://asawicki.info/news_1301_reflect_and_refract_functions.html
http://math.hws.edu/graphicsbook/c7/s2.html
https://math.hws.edu/graphicsbook/source/webgl/spotlights.html 
https://www.geeksforgeeks.org/java/javafx-light-spot-class/
http://www.mathematik.uni-marburg.de/~thormae/lectures/graphics1/code/WebGLShaderLightMat/ShaderLightMat.html
http://www.cs.toronto.edu/~jacobson/phong-demo/
